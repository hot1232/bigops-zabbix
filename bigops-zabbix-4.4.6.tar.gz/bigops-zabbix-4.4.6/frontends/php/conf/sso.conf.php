<?php

$SALT = 'bigops123';

#http的cas用这里
$SSO_SERVER_DOMAIN = 'sso.bigops.com';
$SSO_SERVER_PORT = 80;
$SSO_SERVER_URI = '/signin';
$SSO_LOGIN_URL = 'http://'. $SSO_SERVER_DOMAIN .'/signin/login';
$SSO_LOGOUT_URL = 'http://'. $SSO_SERVER_DOMAIN .'/signin/logout';
$CLIENT_SSO_URL = (($_SERVER['REQUEST_SCHEME'] == 'http') ? 'http' : 'http')
    . '://'
    . $_SERVER['HTTP_HOST']
    . (($_SERVER['SERVER_PORT'] == '80' || $_SERVER['SERVER_PORT'] == '443') ? '' : (':' . $_SERVER['SERVER_PORT']))
    . '/sso.php';

#https的cas用这里
//$SSO_SERVER_DOMAIN = 'sso.bigops.cn';
//$SSO_SERVER_PORT = 443;
//$SSO_SERVER_URI = '/signin';
//$SSO_LOGIN_URL = 'https://'. $SSO_SERVER_DOMAIN .'/signin/login';
//$SSO_LOGOUT_URL = 'https://'. $SSO_SERVER_DOMAIN .'/signin/logout';
//$CLIENT_SSO_URL = (($_SERVER['REQUEST_SCHEME'] == 'https') ? 'https' : 'http')
//    . '://'
//    . $_SERVER['HTTP_HOST']
//    . (($_SERVER['SERVER_PORT'] == '443' || $_SERVER['SERVER_PORT'] == '80') ? '' : (':' . $_SERVER['SERVER_PORT']))
//    . '/sso.php';


//admin用户组id
$ZBX_USER_ADMIN_GROUP_ID = 7;
//默认用户组 id
$ZBX_USER_SSO_GROUP_ID = 200;

$ERR_PAGE_HTML =<<<EOF
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>您所在的用户组被禁用</title>

<style type="text/css">
body {margin: 0px; padding:0px; font-family:"微软雅黑", Arial, "Trebuchet MS", Verdana, Georgia,Baskerville,Palatino,Times; font-size:16px;}
div{margin-left:auto; margin-right:auto;}
a {text-decoration: none; color: #1064A0;}
a:hover {color: #0078D2;}
img { border:none; }
h1,h2,h3,h4 {
/*  display:block;*/
    margin:0;
    font-weight:normal; 
    font-family: "微软雅黑", Arial, "Trebuchet MS", Helvetica, Verdana ; 
}
h1{font-size:24px; color:#17233d; padding:20px 0px 10px 0px;}

#page{width:500px; padding:20px 20px 40px 20px; margin-top:150px; background:#f0faff;}
.button{width:140px; height:24px; margin-left:0px; margin-top:10px; background:#2d8cf0; border-bottom:0px solid #0188DE; text-align:center;}
.button a{width:140px; height:24px; display:block; font-size:14px; color:#fff; }
.button a:hover{ background:#499bf1;}
</style>

</head>
<body>
<div id="page" style="border:1px;border-radius:4px;border-style:solid;border-color:#abdcff;line-height:24px;">
    <h1>您所在的用户组已被禁用，请联系管理员。</h1><br>
    <div class="button">
        <a href="{$SSO_LOGOUT_URL}?service={$CLIENT_SSO_URL}" title="进入首页" target="_parent">进入首页</a>
        <!-- a href="sso.php?logout=1" title="进入首页" target="_parent">进入首页</a -->
    </div>
</div>
</body>
<script>
var keys = document.cookie.match(/[^ =;]+(?=\=)/g);
if(keys) {
    for(var i = keys.length; i--;)
        document.cookie = keys[i] + '=0;expires=' + new Date(0).toUTCString()
}
//window.setTimeout(function(){window.location.href = window.location.href}, 3000);
</script>
</html>
EOF;

function checkCASSession(){
    // 1 session cas null
    // 2 zabbix_sessionid true
    $sso_logout = false;
    session_start();
    if(empty($_SESSION['phpCAS']['user']) && !empty($_COOKIE['zbx_sessionid'])){
        $sso_logout = true;
    }
    session_write_close();
    if($sso_logout){
        Z::getInstance()->do_init();
        CWebUser::logout();
        gotoSSO(trim((!empty($_SERVER['REQUEST_URI'])?$_SERVER['REQUEST_URI']:''),'/'));
    }
}


function gotoSSO($request = ''){
    global $SSO_LOGIN_URL, $CLIENT_SSO_URL;
    header("Location: " . $SSO_LOGIN_URL . '?service=' . urlencode($CLIENT_SSO_URL . (!empty($request)?('?request='.$request):'')));
}

checkCASSession();
