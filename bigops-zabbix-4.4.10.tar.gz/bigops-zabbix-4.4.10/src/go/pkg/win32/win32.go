// +build windows

/*
** Zabbix
** Copyright (C) 2001-2020 Zabbix SIA
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
**/

package win32

import (
	"fmt"
	"syscall"
)

func mustLoadLibrary(name string) Hlib {
	if handle, err := syscall.LoadLibrary(name); err != nil {
		panic(err.Error())
	} else {
		return Hlib(handle)
	}
}

func (h Hlib) mustGetProcAddress(name string) uintptr {
	if addr, err := syscall.GetProcAddress(syscall.Handle(h), name); err != nil {
		panic(fmt.Sprintf("Failed to get function %s: %s", name, err.Error()))
	} else {
		return addr
	}
}

func bool2uintptr(value bool) uintptr {
	if value {
		return 1
	}
	return 0
}

func init() {
}
